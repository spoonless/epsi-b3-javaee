package io.github.spoonless.mvc;

public class DonneesInvalidesException extends Exception {

	public DonneesInvalidesException(String message) {
		super(message);
	}

}
