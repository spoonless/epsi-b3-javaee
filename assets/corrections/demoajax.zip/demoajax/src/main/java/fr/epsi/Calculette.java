package fr.epsi;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

@Named
@RequestScoped
public class Calculette {

	private Double valeur;
	private Double resultat;

	public Double getValeur() {
		return valeur;
	}

	public void setValeur(Double valeur) {
		this.valeur = valeur;
	}

	public Double getResultat() {
		return resultat;
	}

	public void calculer() {
		if (valeur != null) {
			resultat = Math.sqrt(valeur);
		}
	}

}
