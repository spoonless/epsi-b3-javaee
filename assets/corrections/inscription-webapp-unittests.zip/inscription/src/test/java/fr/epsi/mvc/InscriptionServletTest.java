package fr.epsi.mvc;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;

public class InscriptionServletTest {

	private ServletContext servletContext;
	private RequestDispatcher requestDispatcher;
	private HttpServletRequest httpServletRequest;
	private HttpServletResponse httpServletResponse;

	@Before
	public void createMocks() {
		servletContext = mock(ServletContext.class);
		requestDispatcher = mock(RequestDispatcher.class);
		httpServletRequest = mock(HttpServletRequest.class);
		httpServletResponse = mock(HttpServletResponse.class);
	}

	@Test
	public void canForwardToInscriptionViewOnGetRequest() throws Exception {
		InscriptionServlet inscriptionServlet = new InscriptionServlet();

		when(httpServletRequest.getMethod()).thenReturn("GET");
		when(httpServletRequest.getServletContext()).thenReturn(servletContext);
		when(servletContext.getRequestDispatcher("/WEB-INF/views/inscription.jsp")).thenReturn(requestDispatcher);

		inscriptionServlet.service(httpServletRequest, httpServletResponse);

		verify(requestDispatcher).forward(httpServletRequest, httpServletResponse);
	}

	@Test
	public void canValidateInscriptionAndForwardToInscriptionOKWiew() throws Exception {
		InscriptionServlet inscriptionServlet = new InscriptionServlet();

		when(httpServletRequest.getMethod()).thenReturn("POST");
		when(httpServletRequest.getParameter("login")).thenReturn("dummylogin");
		when(httpServletRequest.getParameter("email")).thenReturn("dummy@email");
		when(httpServletRequest.getParameter("conditionsGeneralesApprouvees")).thenReturn("true");

		when(httpServletRequest.getServletContext()).thenReturn(servletContext);
		when(servletContext.getRequestDispatcher("/WEB-INF/views/inscriptionOk.jsp")).thenReturn(requestDispatcher);

		inscriptionServlet.service(httpServletRequest, httpServletResponse);

		verify(requestDispatcher).forward(httpServletRequest, httpServletResponse);
	}

	@Test
	public void cannotValidateInscriptionAndForwardToInscriptionView() throws Exception {
		InscriptionServlet inscriptionServlet = new InscriptionServlet();

		when(httpServletRequest.getMethod()).thenReturn("POST");
		when(httpServletRequest.getServletContext()).thenReturn(servletContext);
		when(servletContext.getRequestDispatcher("/WEB-INF/views/inscription.jsp")).thenReturn(requestDispatcher);

		inscriptionServlet.service(httpServletRequest, httpServletResponse);

		verify(requestDispatcher).forward(httpServletRequest, httpServletResponse);
	}
}
