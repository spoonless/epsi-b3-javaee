package fr.epsi.mvc;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import org.junit.Test;

public class InscriptionTest {

	private Inscription createValidInscription() {
		Inscription inscription = new Inscription();
		inscription.setLogin("dummyLogin");
		inscription.setEmail("dummy@email");
		inscription.setConditionsGeneralesApprouvees(true);
		return inscription;
	}

	@Test
	public void canValidateInscription() throws Exception {
		Inscription inscription = createValidInscription();

		inscription.validate();

		assertNotNull(inscription.getCreation());
	}

	@Test
	public void cannotValidateInscriptionWhenNoLogin() throws Exception {
		Inscription inscription = createValidInscription();
		inscription.setLogin(null);

		InscriptionInvalideException e = cannotValidateInscription(inscription);

		assertExceptionForBadLogin(e);
	}

	@Test
	public void cannotValidateInscriptionWhenLoginContainsWhitespaces() throws Exception {
		Inscription inscription = createValidInscription();
		inscription.setLogin("bad login");

		InscriptionInvalideException e = cannotValidateInscription(inscription);

		assertExceptionForBadLogin(e);
	}

	@Test
	public void cannotValidateInscriptionWhenNoEmail() throws Exception {
		Inscription inscription = createValidInscription();
		inscription.setEmail(null);

		InscriptionInvalideException e = cannotValidateInscription(inscription);

		assertExceptionForBadEmail(e);
	}

	@Test
	public void cannotValidateInscriptionWhenMalformatedEmail() throws Exception {
		Inscription inscription = createValidInscription();
		inscription.setEmail("wrongemail");

		InscriptionInvalideException e = cannotValidateInscription(inscription);

		assertExceptionForBadEmail(e);
	}

	@Test
	public void cannotValidateInscriptionWhenConditionsGeneralesNotApproved() throws Exception {
		Inscription inscription = createValidInscription();
		inscription.setConditionsGeneralesApprouvees(false);

		InscriptionInvalideException e = cannotValidateInscription(inscription);

		assertExceptionForConditionsGenerales(e);
	}

	@Test
	public void cannotValidateInscriptionForSeveralReasons() throws Exception {
		Inscription inscription = new Inscription();
		inscription.setConditionsGeneralesApprouvees(false);

		InscriptionInvalideException e = cannotValidateInscription(inscription);

		assertExceptionForBadLogin(e);
		assertExceptionForBadEmail(e);
		assertExceptionForConditionsGenerales(e);
	}

	private InscriptionInvalideException cannotValidateInscription(Inscription inscription) throws Exception {
		try {
			inscription.validate();
			fail("InscriptionInvalideException expected!");
			throw new Exception("InscriptionInvalideException expected!");
		} catch (InscriptionInvalideException e) {
			return e;
		}
	}

	private void assertExceptionForBadLogin(InscriptionInvalideException e) {
		assertEquals("Le login n'est pas correctement renseigné !", e.getErrorMessages().get("login"));
	}

	private void assertExceptionForBadEmail(InscriptionInvalideException e) {
		assertEquals("L'e-mail est invalide !", e.getErrorMessages().get("email"));
	}

	private void assertExceptionForConditionsGenerales(InscriptionInvalideException e) {
		assertEquals("Vous devez approuver les conditions générales !", e.getErrorMessages().get("conditionsGeneralesApprouvees"));
	}
}
