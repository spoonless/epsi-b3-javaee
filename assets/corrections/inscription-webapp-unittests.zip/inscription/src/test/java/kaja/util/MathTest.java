package kaja.util;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class MathTest {

	@Test
	public void canGetAbsoluteValueFromNegativeInteger() {
		int result = Math.abs(-1);

		assertEquals(1, result);
	}

	@Test
	public void canGetAbsoluteValueFromPositiveInteger() {
		int result = Math.abs(1);

		assertEquals(1, result);
	}

	@Test
	public void canGetAbsoluteValueForZero() {
		int result = Math.abs(0);

		assertEquals(0, result);
	}

	@Test
	public void cannotGetAbsoluteValueFromLeastNegativeValue() {
		int result = Math.abs(Integer.MIN_VALUE);

		assertEquals(Integer.MIN_VALUE, result);
	}
}
