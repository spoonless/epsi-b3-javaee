package fr.epsi.individu;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import javax.sql.DataSource;

@Named
@ApplicationScoped
public class IndividuRepository {

	@Resource(name = "individuDataSource")
	private DataSource dataSource;

	public String create(Individu individu) throws SQLException {
		try (Connection con = dataSource.getConnection();
				PreparedStatement pstmt = con.prepareStatement("insert into individu (nom, prenom, age) values (?, ?, ?)");) {
			pstmt.setString(1, individu.getNom());
			pstmt.setString(2, individu.getPrenom());
			pstmt.setInt(3, individu.getAge());
			pstmt.executeUpdate();
		}
		return "individu?faces-redirect=true";
	}

	public void delete(long id) throws SQLException {
		try (Connection con = dataSource.getConnection();
				PreparedStatement pstmt = con.prepareStatement("delete from individu where id = ?");) {
			pstmt.setLong(1, id);
			pstmt.executeUpdate();
		}
	}

	public List<Individu> getAll() throws SQLException {
		List<Individu> result = new ArrayList<>();
		try (Connection con = dataSource.getConnection();
				Statement stmt = con.createStatement();
				ResultSet resultSet = stmt.executeQuery("select id, nom, prenom, age from individu");) {
			while (resultSet.next()) {
				Individu inscription = new Individu();
				inscription.setId(resultSet.getLong("id"));
				inscription.setNom(resultSet.getString("nom"));
				inscription.setPrenom(resultSet.getString("prenom"));
				inscription.setAge(resultSet.getInt("age"));
				result.add(inscription);
			}
		}
		return result;
	}
}
