package fr.epsi.individu;

import java.util.List;

import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

@Named
@RequestScoped
public class IndividuController {

	@EJB
	private IndividuRepository individuRepository;

	private final Individu individu = new Individu();

	public Individu getIndividu() {
		return individu;
	}

	public String create() {
		individuRepository.create(individu);
		return "individu?faces-redirect=true";
	}

	public String delete() {
		individuRepository.delete(individu);
		return null;
	}

	public List<Individu> getAll() {
		return individuRepository.getAll();
	}

}
