package fr.epsi.individu;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class IndividuRepository {

	@PersistenceContext(unitName = "individuPersistenceUnit")
	private EntityManager entityManager;

	public void create(Individu individu) {
		entityManager.persist(individu);
	}

	public void delete(Individu individu) {
		entityManager.createQuery("delete from Individu i where i.id = :id")
		             .setParameter("id", individu.getId())
		             .executeUpdate();
	}

	public List<Individu> getAll() {
		return entityManager.createQuery("select i from Individu i", Individu.class)
		                    .getResultList();
	}
}
