package fr.epsi.mvc;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

@Named
@RequestScoped
public class AjaxInscriptionService {
	
	@Inject
	private InscriptionService inscriptionService;
	
	private boolean inscriptionValidee;
	
	public boolean isInscriptionValidee() {
		return inscriptionValidee;
	}

	public void inscrire(Inscription inscription) {
		inscriptionService.inscrire(inscription);
		this.inscriptionValidee = true;
	}
}
