package fr.epsi.mvc;

import java.util.Date;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Named
@RequestScoped
public class Inscription {

	@Size(min = 1, message = "{login.invalide}")
	private String login;

	@Pattern(regexp = "\\S+@\\S+", message = "{email.invalide}")
	private String email;

	@AssertTrue(message = "{conditions.non.approuvees}")
	private boolean conditionsGeneralesApprouvees;

	private Date creation;

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getCreation() {
		return creation;
	}

	public boolean isConditionsGeneralesApprouvees() {
		return conditionsGeneralesApprouvees;
	}

	public void setConditionsGeneralesApprouvees(boolean conditionsGeneralesApprouvees) {
		this.conditionsGeneralesApprouvees = conditionsGeneralesApprouvees;
	}

	public void validate() {
		this.creation = new Date();
	}

}
