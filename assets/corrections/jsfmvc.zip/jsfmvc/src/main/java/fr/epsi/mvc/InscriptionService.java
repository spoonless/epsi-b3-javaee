package fr.epsi.mvc;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;

@Named
@ApplicationScoped
public class InscriptionService {

	public String inscrire(Inscription inscription) {
		inscription.validate();
		return "inscriptionOk";
	}

}
