package fr.epsi;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

import java.util.Calendar;

import org.junit.After;
import org.junit.Test;

public class IndividuTest extends JpaTestCase {

	@Test
	public void canPersistAndFindIndividu() {
		Individu individu = createIndividu();

		entityManager.getTransaction().begin();
		entityManager.persist(individu);
		entityManager.getTransaction().commit();

		Individu persistedIndividu = entityManager.find(Individu.class, individu.getId());
		assertSame(persistedIndividu, individu);

		// clear vide le cache de l'entity manager
		entityManager.clear();
		// puisque le cache est vide, l'entity manager est obligé de recharger
		// l'individu depuis la base et l'instance sera donc différente
		persistedIndividu = entityManager.find(Individu.class, individu.getId());
		assertNotSame(persistedIndividu, individu);
	}

	@Test
	public void canMergeIndividu() {
		Individu individu = persistIndividu();

		Individu mergedIndividu = new Individu();
		mergedIndividu.setId(individu.getId());
		mergedIndividu.setNom("merge");

		entityManager.getTransaction().begin();
		mergedIndividu = entityManager.merge(mergedIndividu);
		entityManager.getTransaction().commit();

		// Astuce de OpenJPA : un appel à merge retourne l'entité
		// déjà présente dans l'entity manager et mise à jour avec
		// les nouvelles données.
		assertSame(mergedIndividu, individu);
		assertEquals("merge", mergedIndividu.getNom());
		assertEquals("john", mergedIndividu.getPrenom());
	}

	@Test
	public void canDetachIndividu() {
		Individu individu = persistIndividu();

		// Un appel à detach fait "oublier" l'entité.
		// Donc un appel à find oblige l'entityManager à créer une nouvelle
		// instance.
		entityManager.detach(individu);

		Individu persistedIndividu = entityManager.find(Individu.class, individu.getId());

		assertNotSame(persistedIndividu, individu);
	}

	@Test
	public void canRemoveIndividu() {
		Individu individu = persistIndividu();

		entityManager.getTransaction().begin();
		entityManager.remove(individu);
		entityManager.getTransaction().commit();

		assertNull(entityManager.find(Individu.class, individu.getId()));
	}

	private Individu persistIndividu() {
		Individu individu = createIndividu();

		entityManager.getTransaction().begin();
		entityManager.persist(individu);
		entityManager.getTransaction().commit();
		return individu;
	}

	private Individu createIndividu() {
		Individu individu = new Individu();
		individu.setAge(24);
		individu.setDateAdhesion(Calendar.getInstance());
		individu.setNom("smith");
		individu.setPrenom("john");
		return individu;
	}

	@After
	public void rollbackTransactionIfNecessary() {
		if (entityManager.getTransaction().isActive()) {
			entityManager.getTransaction().rollback();
		}
	}

}
