CREATE TABLE IF NOT EXISTS Adherent (
  id int(11) NOT NULL AUTO_INCREMENT,
  email varchar(200) NOT NULL,
  motDePasse varchar(200) NOT NULL,
  dateAdhesion date NOT NULL,
  PRIMARY KEY (id)
) engine=innodb;

CREATE TABLE IF NOT EXISTS Adresse (
  id int(11) NOT NULL AUTO_INCREMENT,
  rue varchar(200) NOT NULL,
  codePostal varchar(20) NOT NULL,
  ville varchar(200),
  adhesionId int(11) NOT NULL,
  CONSTRAINT FOREIGN KEY (adhesionId) REFERENCES Adherent(id),
  PRIMARY KEY (id)
) engine=innodb;
